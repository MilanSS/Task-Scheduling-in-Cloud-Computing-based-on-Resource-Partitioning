package cloudRP;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Log;
import org.workflowsim.CondorVM;
import org.workflowsim.WorkflowSimTags;
import org.cloudbus.cloudsim.Vm;

public class ProposedAlgo extends Baseschedulingalgo  {

public ProposedAlgo()
{
    super();
}

	private static List sharedVMList;
	private List hasChecked = new ArrayList<Boolean>();

	@Override
	public void run() {
		int size = getCloudletList().size();
		hasChecked.clear();
		for (int t = 0; t < size; t++) {
			boolean chk = false;
			hasChecked.add(false);
		}
		for (int i = 0; i < size; i++) {
			int maxIndex = 0;
			Cloudlet maxCloudlet = null;
			for (int j = 0; j < size; j++) {
				Cloudlet cloudlet = (Cloudlet) getCloudletList().get(j);
				boolean chk = (Boolean) (hasChecked.get(j));
				if (!chk) {
					maxCloudlet = cloudlet;
					maxIndex = j;
					break;
				}
			}
			if (maxCloudlet == null) {
				break;
			}

			for (int j = 0; j < size; j++) {
				Cloudlet cloudlet = (Cloudlet) getCloudletList().get(j);
				boolean chk = (Boolean) (hasChecked.get(j));

				if (chk) {
					continue;
				}

				long length = cloudlet.getCloudletLength();

				if (length > maxCloudlet.getCloudletLength()) {
					maxCloudlet = cloudlet;
					maxIndex = j;
				}
			}
			hasChecked.set(maxIndex, true);

			
			sharedVMList = getVmList();
			quickSort(sharedVMList, 0, getVmList().size() - 1);
			
			int vmSize = sharedVMList.size();
			CondorVM firstIdleVm = null;
			CondorVM lastIdleVm = null;
			int middleVM = getVmList().size() / 2;
			CondorVM midVm = (CondorVM) sharedVMList.get(middleVM);
			for (int j = 0; j < vmSize/2; j++)
            {
                CondorVM vm = (CondorVM) getVmList().get(j);
                CondorVM vml = (CondorVM) getVmList().get(vmSize-j);
                if (vm.getState() == WorkflowSimTags.VM_STATUS_IDLE)
                {
                    firstIdleVm = vm;
                    
                }
                if (vm.getState() == WorkflowSimTags.VM_STATUS_IDLE)
                {
                    lastIdleVm = vml;
                }
                if(lastIdleVm != null && firstIdleVm !=null){
                	break;
                }
            }
            if (firstIdleVm == null)
            {
                break;
            }
			
			for (int j = 0; j < vmSize; j++) {
				CondorVM vm = (CondorVM) getVmList().get(j);
				if ((vm.getState() == WorkflowSimTags.VM_STATUS_IDLE)
						&& vm.getCurrentRequestedTotalMips() > lastIdleVm.getCurrentRequestedTotalMips()) {
					lastIdleVm = vm;

				} else if((vm.getState() == WorkflowSimTags.VM_STATUS_IDLE)
						&& vm.getCurrentRequestedTotalMips() > firstIdleVm.getCurrentRequestedTotalMips()) {
					firstIdleVm = vm;

				}
			}
			firstIdleVm.setState(WorkflowSimTags.VM_STATUS_BUSY);
			maxCloudlet.setVmId(firstIdleVm.getId());
			getScheduledList().add(maxCloudlet);
			Log.printLine("Schedules " + maxCloudlet.getCloudletId() + " with " + maxCloudlet.getCloudletLength()
					+ " to VM " + firstIdleVm.getId() + " with " + firstIdleVm.getCurrentRequestedTotalMips());

		}
	}

	public static void quickSort(List<Vm> arr, int low, int high) {
		arr = sharedVMList;
		if (arr == null || arr.size() == 0)
			return;

		if (low >= high)
			return;

		int middle = low + (high - low) / 2;
		CondorVM vm = (CondorVM) arr.get(middle);
		int pivot = (int) vm.getCurrentRequestedTotalMips();

		int i = low, j = high;
		while (i <= j) {
			CondorVM iVm = (CondorVM) arr.get(i);
			CondorVM jVm = (CondorVM) arr.get(j);
			while ((int) iVm.getCurrentRequestedTotalMips() < pivot) {
				i++;
			}
			
			while ((int)jVm.getCurrentRequestedTotalMips() > pivot) {
				j--;
			}

			if (i <= j) {
				CondorVM temp = iVm;
				arr.set(i, arr.get(j));
				arr.set(j, temp);
				i++;
				j--;
			}
		}
		if (low < j)
			quickSort(arr, low, j);

		if (high > i)
			quickSort(arr, i, high);
	}

}


