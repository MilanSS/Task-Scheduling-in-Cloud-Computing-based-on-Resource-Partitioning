package cloudRP;


import java.util.ArrayList;
import java.util.List;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Log;
import org.workflowsim.CondorVM;
import org.workflowsim.WorkflowSimTags;



public class MaxMinAlgo extends Baseschedulingalgo 
{

    public MaxMinAlgo()
    {
        super();
    }
    
    
    private List hasChecked = new ArrayList<Boolean>();

    @Override
    public void run() 
    {

        
        int size = getCloudletList().size();
        hasChecked.clear();
        for (int t = 0; t < size; t++) 
        {
            boolean chk = false;
            hasChecked.add(false);
        }
        for (int i = 0; i < size; i++) 
        {
            int maxIndex = 0;
            Cloudlet maxCloudlet = null;
            for (int j = 0; j < size; j++)
            {
                Cloudlet cloudlet = (Cloudlet) getCloudletList().get(j);
                boolean chk = (Boolean) (hasChecked.get(j));
                if (!chk) 
                {
                    maxCloudlet = cloudlet;
                    maxIndex = j;
                    break;
                }
            }
            if (maxCloudlet == null) 
            {
                break;
            }


            for (int j = 0; j < size; j++) 
            {
                Cloudlet cloudlet = (Cloudlet) getCloudletList().get(j);
                boolean chk = (Boolean) (hasChecked.get(j));

                if (chk) 
                {
                    continue;
                }

                long length = cloudlet.getCloudletLength();

                if (length > maxCloudlet.getCloudletLength()) 
                {
                    maxCloudlet = cloudlet;
                    maxIndex = j;
                }
            }
            hasChecked.set(maxIndex, true);

            int vmSize = getVmList().size();
            CondorVM firstIdleVm = null;
            for (int j = 0; j < vmSize; j++)
            {
                CondorVM vm = (CondorVM) getVmList().get(j);
                if (vm.getState() == WorkflowSimTags.VM_STATUS_IDLE)
                {
                    firstIdleVm = vm;
                    break;
                }
            }
            if (firstIdleVm == null)
            {
                break;
            }
            for (int j = 0; j < vmSize; j++) 
            {
                CondorVM vm = (CondorVM) getVmList().get(j);
                if ((vm.getState() == WorkflowSimTags.VM_STATUS_IDLE)
                        && vm.getCurrentRequestedTotalMips() > firstIdleVm.getCurrentRequestedTotalMips()) 
                {
                    firstIdleVm = vm;

                }
            }
            firstIdleVm.setState(WorkflowSimTags.VM_STATUS_BUSY);
            maxCloudlet.setVmId(firstIdleVm.getId());
            getScheduledList().add(maxCloudlet);
            Log.printLine("Schedules " + maxCloudlet.getCloudletId() + " with "
                    + maxCloudlet.getCloudletLength() + " to VM " + firstIdleVm.getId()
                    + " with " + firstIdleVm.getCurrentRequestedTotalMips());

        }
    }
}


