package cloudRP;



import java.util.ArrayList;
import java.util.List;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Vm;


public abstract class Baseschedulingalgo implements Schedulinginterface 
{

 
    private List<? extends Cloudlet> cloudletList;
    
   
    private List<? extends Vm> vmList;
    
   
    private List< Cloudlet> scheduledList;

   
    public Baseschedulingalgo() 
    {
        this.scheduledList = new ArrayList();
    }

   
    @Override
    public void setCloudletList(List list) 
    {
        this.cloudletList = list;
    }

    
    @Override
    public void setVmList(List list) 
    {
        this.vmList = new ArrayList(list);
    }

   
    @Override
    public List getCloudletList() 
    {
        return this.cloudletList;
    }

   
    @Override
    public List getVmList() 
    {
        return this.vmList;
    }

   
    public abstract void run() throws Exception;


    @Override
    public List getScheduledList() 
    {
        return this.scheduledList;
    }
}


